<?php
$con=mysqli_connect('localhost','root','','chat1');
?>